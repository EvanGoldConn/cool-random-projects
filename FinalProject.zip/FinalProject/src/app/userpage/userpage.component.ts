import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { User } from '../user/user.model';
import { Pizza } from '../pizza/pizza.model';

@Component({
  selector: 'app-userpage',
  templateUrl: './userpage.component.html',
  styleUrls: ['./userpage.component.css']
})
export class UserpageComponent implements OnInit {
  currentUser: User;


  constructor(private userService: UserService) { 
    this.currentUser = this.userService.getUser();
    console.log(this.currentUser);

  }


 returnUser(): User{
   this.currentUser = this.userService.getUser();

   return this.currentUser;

  }


  

  ngOnInit() {

  }

}
