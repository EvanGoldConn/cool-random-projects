import { Injectable } from "@angular/core";
import { User } from './user/user.model';
import { Pizza } from './pizza/pizza.model';

@Injectable()
export class UserService {
    userJing = new User("jxu2@conncoll.edu","123","Jing","270 Mohegan Ave");
    userEvan = new User("egoldsmi@conncoll.edu","123","Evan","KB");
    userList: Array<User> = [this.userJing,this.userEvan];
    currentUser: User = null;


    setUser(newUser: any) {
        this.currentUser = newUser;
    }

    getUser(): any {
        return this.currentUser;
    }
    setcurrentOrder(order: Array<Pizza>): boolean {
       // console.log(order);
        this.currentUser.setcurrentOrder(order);
        

        return false;
    }

    userRegister(email:string, password:string, name: string, address: string): User {
        var user = new User(email,password,name,address);
        this.userList.push(user);
        this.currentUser = user;
        console.log(this.userList)
        return user;
    }

    userLogin(email: string, password: string): User {
        for(var user of this.userList){
            if(user.email == email){
                if(user.password == password){
                    this.currentUser = user;
                    return user;
                }
            }
        }
        return null;
    }

   

}