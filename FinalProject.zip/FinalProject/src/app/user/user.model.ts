import { Pizza } from '../pizza/pizza.model';


export class User{
    email:string;
    password:string;
    name:string;
    address:string;
    status:boolean;
    allOrders:Array<Array<Pizza>>;
    currentOrder:Array<Pizza>;
   // completedOrder:Array<Pizza>;

    
    constructor(email:string, password:string, name:string,address:string) {
        this.email=email;
        this.password=password;
        this.name=name;
        this.address=address;
        this.status=false;
        this.allOrders=[];
        this.currentOrder=null;
      //  this.completedOrder=[];
    }


    enteredAccount():void{ //check if user successfully logs in (matches the account)
        this.status = true;
    }

   setcurrentOrder(order: Array<Pizza>):void{
       this.currentOrder==order;

     //  console.log(this.allOrders);

   }



}