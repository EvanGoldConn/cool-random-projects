import { Component, OnInit, Input } from '@angular/core';
import { Pizza } from '../pizza/pizza.model';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-pizzaorder',
  templateUrl: './pizzaorder.component.html',
  styleUrls: ['./pizzaorder.component.css']
})
export class PizzaorderComponent implements OnInit {
  @Input() pizza: Pizza;

  currentOrder: Array<Pizza> = [];

  constructor(private userService: UserService, private router:Router) { 

  }


  createOrder(bbqChicken:HTMLInputElement,buffaloChicken:HTMLInputElement,cheese:HTMLInputElement,hawaiianThick:HTMLInputElement,hawaiianThin:HTMLInputElement, meatLovers:HTMLInputElement, mushroom:HTMLInputElement,specialty:HTMLInputElement,vegetarian:HTMLInputElement): boolean { 

    var bbqChickenCheck:boolean = bbqChicken.checked;
    var buffaloChickenCheck:boolean=buffaloChicken.checked;
    var cheeseCheck:boolean=cheese.checked;
    var hawaiianThickCheck:boolean=hawaiianThick.checked;
    var hawaiianThinCheck:boolean=hawaiianThin.checked;
    var meatLoversCheck:boolean=meatLovers.checked;
    var mushroomCheck:boolean=mushroom.checked;
    var specialtyCheck:boolean=specialty.checked;
    var vegetarianCheck:boolean=vegetarian.checked;


    if (bbqChickenCheck){
      var bbqChickenPizza : Pizza = new Pizza("BBQ Chicken", 12, "../assets/images/bbqChicken.PNG");
      this.currentOrder.push(bbqChickenPizza);
    }
    if (buffaloChickenCheck) {
      var buffaloChickenPizza : Pizza = new Pizza("Buffalo Chicken", 12, "../assets/images/buffaloChicken.PNG");
      this.currentOrder.push(buffaloChickenPizza);
    }

    if (cheeseCheck) {
      var cheesePizza : Pizza = new Pizza("Plain Cheese", 12, "../assets/images/cheese.PNG");
      this.currentOrder.push(cheesePizza);
    }

    if (hawaiianThickCheck){
      var hawaiianThickPizza : Pizza = new Pizza("Hawaiian Thick Crust", 12, "../assets/images/hawaiianThick.PNG");
      this.currentOrder.push(hawaiianThickPizza);
    }
    if (hawaiianThinCheck) {
      var hawaiianThinPizza : Pizza = new Pizza("Hawaiian Thin Crust", 12, "../assets/images/hawaiianThin.PNG");
      this.currentOrder.push(hawaiianThinPizza);
    }

    if (meatLoversCheck) {
      var meatLoversPizza : Pizza = new Pizza("Meat Lovers", 14, "../assets/images/meatLovers.PNG");
      this.currentOrder.push(meatLoversPizza);
    }
    if (mushroomCheck){
      var mushroomPizza : Pizza = new Pizza("Spicy Mushroom", 9, "../assets/images/mushroom.PNG");
      this.currentOrder.push(mushroomPizza);
    }
    if (specialtyCheck) {
      var specialityPizza : Pizza = new Pizza("Today's Specialty  ", 12, "../assets/images/specialty.PNG");
      this.currentOrder.push(specialityPizza);
    }

    if (vegetarianCheck) {
      var vegetarianPizza : Pizza = new Pizza("True Vegetarian", 9, "../assets/images/vegetarian.PNG");
      this.currentOrder.push(vegetarianPizza);
    }


   // console.log(this.completeOrder)

   this.userService.currentUser.currentOrder=[];
   this.userService.setcurrentOrder(this.currentOrder);
   this.userService.currentUser.currentOrder=this.currentOrder;
  // console.log("Here is the order history",this.userService.currentUser.orderHistory);
   this.router.navigate(['/userpage']);



    return false;

  }




  ngOnInit() {
  }

}
