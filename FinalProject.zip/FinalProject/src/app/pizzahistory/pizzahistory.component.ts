import { Component, OnInit, Input } from '@angular/core';
import { UserService } from '../user.service';
import { User } from '../user/user.model';
import { Pizza } from '../pizza/pizza.model';

@Component({
  selector: 'app-pizzahistory',
  templateUrl: './pizzahistory.component.html',
  styleUrls: ['./pizzahistory.component.css']
})
export class PizzahistoryComponent implements OnInit {
  @Input() pizza: Pizza;
  currentUser: User;

  constructor(private userService: UserService) {
  this.currentUser = this.userService.getUser();
   }


  orderisCompleted(){
    this.currentUser.allOrders.push(this.currentUser.currentOrder);
    this.currentUser.currentOrder=null;
    console.log("Completed orders",this.currentUser.allOrders)
  }

  ngOnInit() {
  }

}
