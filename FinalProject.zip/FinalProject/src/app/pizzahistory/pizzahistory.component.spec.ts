import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PizzahistoryComponent } from './pizzahistory.component';

describe('PizzahistoryComponent', () => {
  let component: PizzahistoryComponent;
  let fixture: ComponentFixture<PizzahistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PizzahistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PizzahistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
