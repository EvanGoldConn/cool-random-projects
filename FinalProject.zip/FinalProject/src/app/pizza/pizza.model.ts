

export class Pizza{

    pizzaType:string;
    price:number;
    imageURL:string;
    
    constructor(pizzaType:string, price:number,imageURL:string) {

        this.pizzaType=pizzaType;
        this.price=price;
        this.imageURL=imageURL;
    }



}