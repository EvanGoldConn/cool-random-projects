import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{ AngularFontAwesomeModule } from 'angular-font-awesome';

import { AppComponent } from './app.component';
import { UserorderComponent } from './userorder/userorder.component';
import { PizzaComponent } from './pizza/pizza.component';
import { UserComponent } from './user/user.component';
import { AppRoutingModule } from './app-routing.module';
import {ReactiveFormsModule, FormsModule } from '@angular/forms';
import { UserService } from './user.service';
import { Routes, RouterModule } from '@angular/router';
import { UserpageComponent } from './userpage/userpage.component';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
import { PizzaorderComponent } from './pizzaorder/pizzaorder.component';
import { PizzahistoryComponent } from './pizzahistory/pizzahistory.component';
const routes: Routes = [
  // basic routes
   {path:'', redirectTo: 'home', pathMatch:'full'},
   {path:'home',component:HomeComponent},
   {path:'userorder', component:UserorderComponent},
   {path:'userpage',component:UserpageComponent},
   {path:'about', component:AboutComponent},
   {path:'pizzaorder',component:PizzaorderComponent},
   {path:'pizzahistory',component:PizzahistoryComponent}
   
  
]

@NgModule({
  declarations: [
    AppComponent,
    UserorderComponent,
    PizzaComponent,
    UserComponent,
    UserpageComponent,
    AboutComponent,
    HomeComponent,
    PizzaorderComponent,
    PizzahistoryComponent
  ],
  imports: [
    BrowserModule,
    AngularFontAwesomeModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [{provide:UserService, useClass:UserService}],
  bootstrap: [AppComponent]

})
export class AppModule { }
