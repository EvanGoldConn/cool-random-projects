import { Component, OnInit } from '@angular/core';
import { User } from '../user/user.model';
import { FormGroup, AbstractControl, FormBuilder, Validators, FormControl } from '@angular/forms';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

//Validators, FormBuilder
@Component({
  selector: 'app-userorder',
  templateUrl: './userorder.component.html',
  styleUrls: ['./userorder.component.css']
})
export class UserorderComponent implements OnInit {
  CurrentUser: User;
 // CurrentUser:Array<User>;
  myForm: FormGroup; //form for logging in user
  myNewForm: FormGroup; //form for registering user
  myEmail: AbstractControl;
  myPassword: AbstractControl;
  emailInput:string;
  passwordInput:string;
  newemailInput:string;
  newpasswordInput:string;
  newaddressInput:string;
  newnameInput:string;
  mynewEmail:AbstractControl;
  mynewPassword:AbstractControl;
  mynewAddress:AbstractControl;
  mynewName:AbstractControl;



  constructor(fb:FormBuilder, private userService: UserService, private router:Router) {
    this.myForm=fb.group({
      'email': ['', Validators.compose([
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ])],
      'password':['',[Validators.required]]

    });
    this.myNewForm=fb.group({
      'newemail': ['', Validators.compose([
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ])],
      'newpassword':['',[Validators.required]],
      'newname':['',[Validators.required]],
      'newaddress':['',[Validators.required]]

    });

    //for login
    this.myEmail=this.myForm.controls['email'];
    this.myPassword=this.myForm.controls['password'];

    this.emailInput=this.myEmail.value;
    this.passwordInput=this.myPassword.value;
    //for register
    this.mynewEmail=this.myNewForm.controls['newemail'];
    this.mynewPassword=this.myNewForm.controls['newpassword'];
    this.mynewAddress=this.myNewForm.controls['newaddress'];
    this.mynewName=this.myNewForm.controls['newname'];

    this.newemailInput=this.mynewEmail.value;
    this.newpasswordInput=this.mynewPassword.value;
    this.newnameInput=this.mynewName.value;
    this.newaddressInput=this.mynewAddress.value;
 //   this.CurrentUser=[];



   }


   userCreate(): boolean {
    console.log(this.myNewForm.value.newemail); 
    //After validating values
    this.CurrentUser = this.userService.userRegister(this.myNewForm.value.newemail,this.myNewForm.value.newpassword,this.myNewForm.value.newname,this.myNewForm.value.newaddress);
    //var user: User = new User(email.value, password.value, name.value, address.value);
    this.router.navigate(['/userpage'])

    // this.UserList.push(user);
   //  console.log(this.UserList);
   //Form.reset here
    this.myNewForm.reset();


    return false;
   }



   userLoginAccount(form:any): boolean { 
     //console.log(this.UserList)
     console.log(this.myForm.value);
     

     this.CurrentUser = this.userService.userLogin(this.myForm.value.email,this.myForm.value.password);
     this.myForm.reset(); //clears form


    if (this.CurrentUser){
      console.log("succesful log in ");
      this.router.navigate(['/userpage'])
      return true;
      
    }else{
      console.log("unsuccessful log in ");
      return false;

    }
  }
  


  // currentUser(): User {
  //   return this.CurrentUser[0];
  // }



  ngOnInit() {
  }

}
